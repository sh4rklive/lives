<?php

define('FILENAME', "marker.txt");

$clean = [];
$list = [];

if (!file_exists(FILENAME)) touch(FILENAME);

isset($_GET['clear'])? fopen(FILENAME, 'w'): null;

function reading(array $list){
    $handle = fopen(FILENAME, 'r');
    while (!feof($handle)){
        $line = fgets($handle, 4096);
        array_push($list, $line);
    }
    fclose($handle);
    $last = sizeof($list) -1;
    unset($list[$last]);
    return $list;
}

function unique(array $list, array $clean){
    $raw = reading($list);
    $dirty = array_unique($raw);
    foreach ($dirty as $value){
        array_push($clean, $value);
    }
    return $clean;
}

$unique = unique($list, $clean);
?>

<!doctype html>
<html lang="pt-br">
    <head>
        <title>#Contador</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
        <style>
            th, td {text-align: center;}
            table {margin-top: 20px;}
            span {color: crimson;}
        </style>
    </head>
    <body>
    <div class="container">
        <table class="striped">
            <tr>
                <th>ID</th>
                <th>DADOS</th>
                <th>IP</th>
                <th>IP REVERSO</th>
                <th>TOTAL: <span><?=count($unique);?></span></th>
            </tr>
            <tr>
                <?php foreach ($unique as $id => $value): $params = explode('|', $value); ?>
                <td><?=++$id;?></td>
                <td><?=$params[0];?></td>
                <td><?=$params[1];?></td>
                <td><?=$params[2];?></td>
                <td></td>
            </tr>
            <?php endforeach;?>
        </table>
    </div>
    </body>
</html>