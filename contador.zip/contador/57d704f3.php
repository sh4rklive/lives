<?php

$date = date('d-m-Y');
$ip = $_SERVER['REMOTE_ADDR'];
$reverse = gethostbyaddr($_SERVER['REMOTE_ADDR']);

$data = [$date, $ip, $reverse];
$params = implode('|', $data);

$handle = fopen('marker.txt', 'a+');
$line = $params . "\n";
fwrite($handle, $line);
fclose($handle);